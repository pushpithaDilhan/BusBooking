<?php 
	
	$connection = mysqli_connect('localhost', 'root', '', 'busticketing');

	if (mysqli_connect_errno()) {
		die("Something went wrong.");
	}
?>